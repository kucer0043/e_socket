from setuptools import setup

setup(
    name='e_socket',
    version='0.1',
    packages=['e_socket'],
    url='https://github.com/kucer0043/e_socket',
    license='',
    author='kucer0043',
    author_email='kucer0043@gmail.com',
    description='Easy Sockets'
)
