from setuptools import setup

setup(
    name='esocket',
    version='0.1',
    packages=['esocket'],
    url='https://github.com/kucer0043/e_socket',
    license='',
    author='kucer0043',
    author_email='kucer0043@gmail.com',
    description='Easy Sockets'
)
